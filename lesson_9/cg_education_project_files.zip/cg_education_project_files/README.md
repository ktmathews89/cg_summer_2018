# CG Education - JavaScript

HTML and CSS skeleton for CoderGirl 2018's final JavaScript project.
* Flexbox-based layout with responsive web design and animations

### Authors ###

* Annie McCance, anniemccance@gmail.com
* Christine Stavridis, castavridis@gmail.com